export class Requests {
    constructor(
        public id: string,
        public name: string,
        public category: string,
        public descreq: string,
    ){}
}