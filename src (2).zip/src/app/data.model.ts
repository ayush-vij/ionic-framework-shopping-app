export class Data{
    constructor(
        public id: string,
        public item_name: string,
        public item_price: number,
        public item_Qty: number,
        public item_img: string,
        ){}
}