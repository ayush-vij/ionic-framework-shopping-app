export interface data {
    id: string,
    item_name: string,
    item_price: number,
    item_Qty: number,
    item_img: string,
}